Select
  'country/Region',
  sum(Recovered)  AS HighamountRecovered
  
FROM
`corona virus dataset`

Group by
    'country/Region'
    
order by
     HighamountRecovered DESC
     LIMIT 2;


