select
  'country/Region',
  MAX(Deaths)  AS lowerdeathcases
  
FROM
`corona virus dataset`

Group by
    'country/Region'
    
order by
     lowerdeathcases ASC
     LIMIT 2;

   