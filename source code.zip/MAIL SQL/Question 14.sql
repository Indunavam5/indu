select
  'country/Region',
  MAX(Confirmed)  AS TotalConfirmecCases
  
FROM
`corona virus dataset`

Group by
    'country/Region'
    
order by
     TotalConfirmecCases DESC
     LIMIT 2;

   
       
  
  
  