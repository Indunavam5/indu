select
SUM(Recovered) AS TotalRecovered,
AVG(Recovered) AS AVGRecovered,
variance(Recovered) AS VarianceRecovered,
stddev(Recovered) AS stddevRecovered

FROM
indu_intern.`corona virus dataset`