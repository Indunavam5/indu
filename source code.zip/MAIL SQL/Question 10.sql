select
  month(Date) AS Month,
  Year(Date) AS Year,
  SUM(Confirmed) AS Totalconfirmed,
  SUM(Deaths) AS TotalDeaths,
  SUM(Recovered) AS TotalRecovery
  
  FROM
  indu_intern.`corona virus dataset`
  
  Group by
   Month(Date),
   year(Date);
