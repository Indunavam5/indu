select
SUM(Confirmed) AS TotalConfirmed,
AVG(Confirmed) AS AVGConfirmed,
variance(Confirmed) AS VarianceConfirmed,
stddev(Confirmed) AS stddevConfirmed

FROM
indu_intern.`corona virus dataset`