SELECT
    COUNT(DISTINCT DATE_FORMAT (DATE, '%Y-%M')) AS Number_of_months
FROM
`corona virus dataset`;