select 
year(Date) AS Year,
max(Confirmed) AS Maxconfirmed,
max(Deaths) AS MaxDeaths,
max(Recovered) AS MaxRecovered

from
`corona virus dataset`

Group by
   year;