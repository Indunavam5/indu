select
Month(Date) as month,
year(Date) AS Year,
substring_index(GROUP_CONCAT(Confirmed order by confirmed DESC),',',1) AS mostfrequentConfirmed,
substring_index(GROUP_CONCAT(Deaths order by deaths DESC),',',1) AS mostfrequentDeath,
substring_index(GROUP_CONCAT(Recovered order by Recovered DESC),',',1) AS mostfrequentRecovered

FROM indu_intern.`corona virus dataset`

Group by
   Month(Date),
   year(Date);



  


