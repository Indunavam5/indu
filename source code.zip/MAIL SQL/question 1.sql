SELECT * FROM indu_intern.`corona virus dataset`
WHERE 
'province' is null or 
'Country/Region' is null or 
'Latitude' is null or 
'Longitude' is null or 
'Date' is null or 
'Confirmed' is null or 
'Deaths' is null or 
'Recovered' is null;

