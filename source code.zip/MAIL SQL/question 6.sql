select
Month(Date) AS Month,
YEAR(date) AS Year,
avg(Confirmed)AS Avgconfirmed,
avg(Deaths) AS Avgdeaths,
avg(Recovered) AS AvgRecovered

from
    `corona virus dataset`

Group by
  
   Month(Date),
   year(Date)
   
ORDER BY
    YEAR(Date),
    MONTH(Date);
    