SELECT min(date) AS StartDate ,max(Date) as ENDDate from indu_intern.`corona virus dataset`
