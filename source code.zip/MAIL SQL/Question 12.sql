select
month(Date) AS MONTH,
SUM(Deaths) AS TotalDeaths,
AVG(Deaths) AS AVGDeaths,
variance(Deaths) AS VarianceDeaths,
stddev(Deaths) AS StdevDeaths

FROM
`corona virus dataset`

Group by
   MONTH;