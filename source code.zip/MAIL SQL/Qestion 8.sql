select 
year(Date) AS Year,
MIN(Confirmed) AS Minconfirmed,
MIN(Deaths) AS MinDeaths,
MIN(Recovered) AS MinRecovered

from
`corona virus dataset`

Group by
   year;


